# 可嵌入角色组件

这是独立角色运行包，不包含制作工作台或 Nextra。把整个文件夹复制到目标网页的静态目录，用本地/站点 HTTP 服务打开 index.html。

```html
<script type="module" src="./character/character-rig.js"></script>
<character-rig src="./character/rig/rig.json" interaction="both" controls="hover" style="width:480px;height:420px"></character-rig>
```

interaction: drag / hover / both / none。controls: visible / hover / hidden。
透明背景、Shadow DOM 样式隔离、多实例独立。元素的 ready Promise 就绪后，通过 element.rig.setPose / reset / play / pause / exportPose / importPose 操作。移除 DOM 自动停止 RAF 并释放 WebGL 和监听器。

全部素材需与页面同源，不支持 file:// 或未配置的跨域素材。默认遵循系统减少动态效果偏好。保留原图身份及有限幅度，不包含隐藏解剖重建。

双骨 IK 的 MIT 许可保留于 rig-vendor/LICENSE-Rev2D.txt。
